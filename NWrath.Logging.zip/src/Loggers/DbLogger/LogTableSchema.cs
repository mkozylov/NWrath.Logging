﻿using Newtonsoft.Json;
using NWrath.Synergy.Common.Extensions.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NWrath.Logging
{
    public class LogTableSchema
        : ILogTableSchema
    {
        #region DefaultColumns

        public static LogTableColumnSchema IdColumn => new LogTableColumnSchema
        {
            Name = "Id",
            RawDbType = "BIGINT",
            IsKey = true,
            AllowNull = false,
            IsInternal = true
        };

        public static LogTableColumnSchema TimestampColumn => new LogTableColumnSchema
        {
            Name = "Timestamp",
            RawDbType = "DATETIME",
            AllowNull = false,
            Serializer = new LambdaLogSerializer(m => $"{m.Timestamp:yyyy-MM-ddTHH:mm:ss.fff}")
        };

        public static LogTableColumnSchema MessageColumn => new LogTableColumnSchema
        {
            Name = "Message",
            RawDbType = "VARCHAR(MAX)",
            AllowNull = false,
            Serializer = new LambdaLogSerializer(m => $"{m.Message}")
        };

        public static LogTableColumnSchema ExceptionColumn => new LogTableColumnSchema
        {
            Name = "Exception",
            RawDbType = "VARCHAR(MAX)",
            AllowNull = true,
            Serializer = new LambdaLogSerializer(m => $"{m.Exception}")
        };

        public static LogTableColumnSchema LevelColumn => new LogTableColumnSchema
        {
            Name = "Level",
            RawDbType = "INT",
            AllowNull = false,
            Serializer = new LambdaLogSerializer(m => m.Level)
        };

        public static LogTableColumnSchema ExtraColumn => new LogTableColumnSchema
        {
            Name = "Extra",
            RawDbType = "VARCHAR(MAX)",
            AllowNull = true,
            Serializer = new LambdaLogSerializer(m => (m.Extra.Count == 0 ? null : m.Extra.AsJson()))
        };

        #endregion DefaultColumns

        public const string DefaultTableName = "ServerLog";

        public static LogTableColumnSchema[] DefaultColumns => GetDefaultColumns();

        public string TableName
        {
            get => _tableName;
            set { _tableName = value; OnUpdated(); }
        }

        public string InserLogScript
        {
            get => _inserLogScript;
            set { _inserLogScript = value ?? BuildDefaultInserLogScript(); OnUpdated(); }
        }

        public string InitScript
        {
            get => _initScript;
            set { _initScript = value ?? BuildDefaultInitScript(); OnUpdated(); }
        }

        public event EventHandler Updated;

        private string _tableName;
        private string _inserLogScript;
        private string _initScript;
        private List<LogTableColumnSchema> _columns;

        public LogTableSchema(
            string tableName = DefaultTableName,
            string initScript = null,
            string inserLogScript = null,
            LogTableColumnSchema[] columns = null
            )
        {
            _tableName = tableName;
            _initScript = initScript;
            _inserLogScript = inserLogScript;

            if (columns?.Length > 0)
            {
                columns.Each(c =>
                {
                    c.Updated -= OnUpdated;
                });

                _columns = columns.ToList();
            }
            else
            {
                _columns = DefaultColumns.ToList();
            }

            _columns.Each(c =>
            {
                c.Updated += OnUpdated;
            });

            OnUpdated();
        }

        public LogTableSchema ApplyColumn(string columnName, Action<LogTableColumnSchema> apply)
        {
            var column = GetColumn(columnName);

            if (column != null)
            {
                apply(column);
            }

            return this;
        }

        public LogTableSchema ClearColumns()
        {
            _columns.Each(c =>
            {
                c.Updated -= OnUpdated;
            });

            _columns.Clear();

            OnUpdated();

            return this;
        }

        public LogTableSchema AddColumn(params LogTableColumnSchema[] columns)
        {
            _columns.AddRange(columns);

            columns.Each(c =>
            {
                c.Updated -= OnUpdated;
                c.Updated += OnUpdated;
            });

            OnUpdated();

            return this;
        }

        public LogTableSchema AddColumn(Action<LogTableColumnSchema> columnApply)
        {
            var column = new LogTableColumnSchema();

            columnApply(column);

            column.Updated -= OnUpdated;
            column.Updated += OnUpdated;

            _columns.Add(column);

            return this;
        }

        public LogTableSchema RemoveColumn(LogTableColumnSchema column)
        {
            column.Updated -= OnUpdated;

            _columns.Remove(column);

            OnUpdated();

            return this;
        }

        public LogTableSchema RemoveColumn(string columnName)
        {
            var column = _columns.FirstOrDefault(x => x.Name == columnName);

            if (column != null)
            {
                column.Updated -= OnUpdated;

                _columns.Remove(column);
            }

            OnUpdated();

            return this;
        }

        public LogTableColumnSchema[] GetColumns()
        {
            return _columns.ToArray();
        }

        public LogTableColumnSchema GetColumn(string columnName)
        {
            return _columns.FirstOrDefault(x => x.Name == columnName);
        }

        private string BuildDefaultInserLogScript()
        {
            var columnNames = _columns.Where(x => !x.IsInternal)
                                     .Select(x => x.Name)
                                     .ToList();

            var columnsStr = string.Join(", ", columnNames);
            var valsStr = string.Join(", ", columnNames.Select(x => $"@{x}"));

            return $"INSERT INTO {TableName}({columnsStr}) VALUES({valsStr})";
        }

        private string BuildDefaultInitScript()
        {
            var cols = _columns.OrderByDescending(c => c.IsKey)
                              .ToList();

            var tableBuilder = new StringBuilder()
                                .Append($"IF OBJECT_ID(N'{TableName}', N'U') IS NULL ")
                                .Append("BEGIN ")
                                .Append($"CREATE TABLE {TableName}(");

            for (int i = 0; i < cols.Count; i++)
            {
                var col = cols[i];

                tableBuilder = tableBuilder.Append($"{col.Name} {col.RawDbType}")
                                           .Append($"{ThenValElseEmpty(!col.AllowNull, " NOT")} NULL")
                                           .Append($"{ThenValElseEmpty(col.IsKey, " PRIMARY KEY IDENTITY")}")
                                           .Append($"{ThenValElseEmpty(i < cols.Count - 1, ",")}");
            }

            tableBuilder = tableBuilder.Append(")")
                                       .Append(" END");

            return tableBuilder.ToString();
        }

        private void OnUpdated(object sender = null, EventArgs e = null)
        {//todo refactor
            sender = sender ?? this;
            e = e ?? EventArgs.Empty;

            _inserLogScript = _inserLogScript ?? BuildDefaultInserLogScript();

            _initScript = _initScript ?? BuildDefaultInitScript();

            Updated?.Invoke(sender, e);
        }

        private static LogTableColumnSchema[] GetDefaultColumns()
        {
            var newMessageColumn = MessageColumn;
            newMessageColumn.Serializer = new LambdaLogSerializer(m => $"{m.Message}{(m.Exception == null ? "" : Environment.NewLine)}{m.Exception}");

            return new LogTableColumnSchema[]
            {
                IdColumn,
                TimestampColumn,
                newMessageColumn,
                LevelColumn,
            };
        }

        private static string ThenValElseEmpty(bool predicate, string thenVal)
        {
            return predicate ? thenVal : "";
        }
    }
}