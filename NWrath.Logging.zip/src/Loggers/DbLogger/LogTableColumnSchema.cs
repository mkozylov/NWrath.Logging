﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NWrath.Logging
{
    public class LogTableColumnSchema
    {
        public string Name { get => _name; set { _name = value; OnUpdated(); } }

        public string RawDbType { get => _rawDbType; set { _rawDbType = value; OnUpdated(); } }

        public string RawDefaultValue { get => _rawDefaultValue; set { _rawDefaultValue = value; OnUpdated(); } }

        public bool AllowNull { get => _allowNull; set { _allowNull = value; OnUpdated(); } }

        public bool IsKey { get => _isKey; set { _isKey = value; OnUpdated(); } }

        public bool IsInternal { get => _isInternal; set { _isInternal = value; OnUpdated(); } }

        public ILogSerializer Serializer { get => _serializer; set { _serializer = value; OnUpdated(); } }

        public string SerializerExpr
        {
            get { return _serializerExpr; }

            set
            {
                _serializerExpr = value;

                Serializer = (LambdaLogSerializer)_serializerExpr;
            }
        }

        public event EventHandler Updated;

        private string _serializerExpr;
        public string _name;
        public string _rawDbType;
        public string _rawDefaultValue;
        public bool _allowNull;
        public bool _isKey;
        public bool _isInternal;
        public ILogSerializer _serializer;

        ~LogTableColumnSchema()
        {
            Updated = null;
        }

        public LogTableColumnSchema Clone()
        {
            return (LogTableColumnSchema)MemberwiseClone();
        }

        private void OnUpdated()
        {
            Updated?.Invoke(this, EventArgs.Empty);
        }
    }
}