﻿using NWrath.Synergy.Common.Structs;

namespace NWrath.Logging
{
    public interface ILoggingWizardCharms
    {
        Set Library { get; set; }
    }
}