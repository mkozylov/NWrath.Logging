﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NWrath.Logging
{
    public enum LogLevel
    {
        Debug,
        Info,
        Warning,
        Error,
        Critical
    }
}