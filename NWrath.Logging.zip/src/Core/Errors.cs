﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NWrath.Logging
{
    public static class Errors
    {
        public const string NO_LOGGERS = "You need set one or more loggers!";
    }
}