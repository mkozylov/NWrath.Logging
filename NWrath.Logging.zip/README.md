# NWrath.Logging
Simple logging infrastructure
